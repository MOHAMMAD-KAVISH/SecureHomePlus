package com.example.securehomeplus.ui.login

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.securehomeplus.R
import com.example.securehomeplus.data.database.AppDatabase
import com.example.securehomeplus.data.repository.UserRepository
import com.example.securehomeplus.databinding.ActivityLoginBinding
import com.example.securehomeplus.ui.dashboard.DashboardActivity
import com.example.securehomeplus.ui.register.RegisterActivity
import com.example.securehomeplus.utils.ValidationUtils
import com.example.securehomeplus.utils.PreferencesManager
import com.example.securehomeplus.viewmodel.AuthViewModel
import com.example.securehomeplus.viewmodel.AuthViewModelFactory

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var viewModel: AuthViewModel
    private lateinit var prefs: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Preferences
        prefs = PreferencesManager(this)

        // Repository + ViewModel setup
        val dao = AppDatabase.getDatabase(this).userDao()
        val repository = UserRepository(dao)
        val factory = AuthViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory)[AuthViewModel::class.java]

        // Already logged in check
        if (prefs.isLoggedIn()) {
            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
        }

        // Login button click
        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            if (!ValidationUtils.isValidEmail(email)) {
                binding.etEmail.error = "Invalid email"
            } else if (password.isEmpty()) {
                binding.etPassword.error = "Enter password"
            } else {
                viewModel.loginUser(email, password)
            }
        }

        // Navigate to Register page
        binding.tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        // Observe login result
        viewModel.loginResult.observe(this) { user ->
            if (user != null) {
                prefs.saveLogin(user.email)
                Toast.makeText(this, "Welcome ${user.name}", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, DashboardActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
